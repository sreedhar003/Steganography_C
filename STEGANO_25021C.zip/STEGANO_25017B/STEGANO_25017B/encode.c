/**************************************************************************************
 * File Name     : encode.c
 * Description   : Contains all function definitions for encoding secret data into BMP image
 * Author        : S Sreedhar
 * Date          : 23/10/2025
 * Project       : LSB Image Steganography (Encoding Part)
 **************************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/**************************************************************************************
 * Function Name : get_image_size_for_bmp
 * Description   : Reads width and height from BMP header and calculates total image size
 * Input         : FILE pointer to source BMP image
 * Output        : Returns total image size in bytes (width * height * 3)
 **************************************************************************************/
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    fseek(fptr_image, 18, SEEK_SET); // Move to 18th byte (width offset)
    fread(&width, sizeof(int), 1, fptr_image); // Read width (4 bytes)
    printf("width = %u\n", width);

    fread(&height, sizeof(int), 1, fptr_image); // Read height (4 bytes)
    printf("height = %u\n", height);

    return width * height * 3; // Return total image size (3 bytes per pixel)
}

/**************************************************************************************
 * Function Name : get_file_size
 * Description   : Finds and returns size of secret file in bytes
 * Input         : FILE pointer to secret file
 * Output        : File size (uint)
 **************************************************************************************/
uint get_file_size(FILE *fptr)
{
    uint size = 0;
    fseek(fptr, 0, SEEK_END); // Move to end of file
    size = ftell(fptr);       // Get current pointer position = size
    rewind(fptr);             // Reset file pointer to beginning
    return size; 
}

/**************************************************************************************
 * Function Name : read_and_validate_encode_args
 * Description   : Validates command line arguments for encoding operation
 * Input         : argv[] and EncodeInfo structure
 * Output        : e_success or e_failure based on validation
 **************************************************************************************/
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    // Validate file arguments for proper extensions
    if(argv[2][0]=='.'||argv[3][0]=='.')
    {
        printf("Invalid file argument\n");
        return e_failure;
    }

    // Check if source image is BMP
    if(strstr(argv[2],".bmp")==NULL)
    {
        printf("Invalid Source file argument\n");
        return e_failure;
    }

    // Check secret file extension validity
    if(strstr(argv[3],".txt")==NULL && strstr(argv[3],".c")==NULL && strstr(argv[3],".h")==NULL && strstr(argv[3],".sh")==NULL)
    {
        printf("Invalid Secret file argument\n");
        return e_failure;
    }

    // Assign default output file name if not provided
    if(argv[4]==NULL)
        encInfo->stego_image_fname = "default.bmp";
    else
        encInfo->stego_image_fname = argv[4];

    // Store filenames into structure
    encInfo->src_image_fname = argv[2];
    encInfo->secret_fname = argv[3];

    // Extract file extension of secret file
    char *dot = strrchr(encInfo->secret_fname, '.');
    if (dot == NULL)
    {
        printf("Error: Secret file has no extension.\n");
        return e_failure;
    }
    else
    {
        if (strlen(dot) > 5) // Restrict extension length
        {
            printf("Error: File extension '%s' too long.\n", dot);
            return e_failure;
        }
        strcpy(encInfo->extn_secret_file, dot); // Copy extension
        printf("Secret file extension: %s\n", encInfo->extn_secret_file);
    }
    return e_success;
}

/**************************************************************************************
 * Function Name : open_files
 * Description   : Opens source image, secret file, and output (stego) file
 * Input         : EncodeInfo structure
 * Output        : e_success or e_failure
 **************************************************************************************/
Status open_files(EncodeInfo *encInfo)
{
    // Open source BMP image file in read mode
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);
        return e_failure;
    }

    // Open secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);
        return e_failure;
    }

    // Open destination (stego) image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);
        return e_failure;
    }

    return e_success;
}

/**************************************************************************************
 * Function Name : check_capacity
 * Description   : Checks if source image has enough capacity to hide secret data
 * Input         : EncodeInfo structure
 * Output        : e_success or e_failure
 **************************************************************************************/
Status check_capacity(EncodeInfo *encInfo)
{
    uint image_size = get_image_size_for_bmp(encInfo->fptr_src_image);
    uint secret_size = get_file_size(encInfo->fptr_secret);
    encInfo->size_secret_file = secret_size;

    // Capacity check formula
    if(image_size >= (54 + strlen(MAGIC_STRING) + strlen(encInfo->extn_secret_file) + 4 + 4 + secret_size) * 8)
        return e_success;
    else
    {
        printf("Insufficient Capacity\n");
        return e_failure;
    }
}

/**************************************************************************************
 * Function Name : copy_bmp_header
 * Description   : Copies first 54 bytes (header) from source BMP to destination BMP
 * Input         : Source and destination file pointers
 * Output        : e_success or e_failure
 **************************************************************************************/
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char image_buffer[54];
    if(fread(image_buffer, 1, 54, fptr_src_image) != 54)
    {
        printf("Error Reading BMP Header\n");
        return e_failure;
    }
    if(fwrite(image_buffer, 1, 54, fptr_dest_image) != 54)
    {
        printf("Error writing BMP Header\n");
        return e_failure;
    }
    printf("BMP Header Copied Successfully...\n");
    return e_success;
}

/**************************************************************************************
 * Function Name : encode_magic_string
 * Description   : Encodes a predefined magic string into LSBs of BMP pixels
 **************************************************************************************/
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    int len = strlen(magic_string);
    char image_buffer[8];
    for(int i = 0; i < len; i++)
    {
        fread(image_buffer, 1, 8, encInfo->fptr_src_image); // Read 8 bytes
        encode_byte_to_lsb(magic_string[i], image_buffer);  // Encode one character
        fwrite(image_buffer, 1, 8, encInfo->fptr_stego_image);
    }
    printf("Magic string encoded successfully ✅\n");
    return e_success; 
}

/**************************************************************************************
 * Function Name : encode_secret_file_extn_size
 * Description   : Encodes size of secret file extension into image
 **************************************************************************************/
Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo)
{
    char image_buff[32];
    fread(image_buff, 1, 32, encInfo->fptr_src_image);
    encode_size_to_lsb(size, image_buff);
    fwrite(image_buff, 1, 32, encInfo->fptr_stego_image);
    printf("Encoded secret file extension size successfully!\n");
    return e_success;
}

/**************************************************************************************
 * Function Name : encode_secret_file_extn
 * Description   : Encodes the actual secret file extension (.txt, .c, etc.)
 **************************************************************************************/
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    char image_buffer[8];
    for(int i = 0; i < strlen(file_extn); i++)
    {
        fread(image_buffer, 1, 8, encInfo->fptr_src_image);
        encode_byte_to_lsb(file_extn[i], image_buffer);
        fwrite(image_buffer, 1, 8, encInfo->fptr_stego_image);
    }
    return e_success; 
}

/**************************************************************************************
 * Function Name : encode_secret_file_size
 * Description   : Encodes total size of secret file in bytes into image
 **************************************************************************************/
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char image_buff[32];
    fread(image_buff, 1, 32, encInfo->fptr_src_image);
    encode_size_to_lsb(file_size, image_buff);
    fwrite(image_buff, 1, 32, encInfo->fptr_stego_image);
    printf("Encoded secret file size successfully!\n");
    return e_success;
}

/**************************************************************************************
 * Function Name : encode_secret_file_data
 * Description   : Encodes entire secret file content byte by byte into LSBs
 **************************************************************************************/
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    rewind(encInfo->fptr_secret); // Go to start of secret file
    fread(encInfo->secret_data, encInfo->size_secret_file, 1, encInfo->fptr_secret); // Read entire data
    char buffer[8];
    for(size_t i = 0; i < encInfo->size_secret_file; i++)
    {
        fread(buffer, 1, 8, encInfo->fptr_src_image);
        encode_byte_to_lsb(encInfo->secret_data[i], buffer);
        fwrite(buffer, 1, 8, encInfo->fptr_stego_image);
    }
    return e_success;
}

/**************************************************************************************
 * Function Name : copy_remaining_img_data
 * Description   : Copies all remaining data (unused pixels) from source to destination
 **************************************************************************************/
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;
    while (fread(&ch, 1, 1, fptr_src) == 1)
        fwrite(&ch, 1, 1, fptr_dest);

    printf("Remaining image data copied successfully!\n");
    return e_success;
}

/**************************************************************************************
 * Function Name : encode_byte_to_lsb
 * Description   : Replaces least significant bit of each byte with secret bit
 **************************************************************************************/
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for (int i = 0; i < 8; i++)
        image_buffer[i] = (image_buffer[i] & ~1) | ((data >> (7 - i)) & 1);
    return e_success;
}

/**************************************************************************************
 * Function Name : encode_size_to_lsb
 * Description   : Encodes integer size value (32 bits) into LSBs of 32 bytes
 **************************************************************************************/
Status encode_size_to_lsb(int size, char *imageBuffer)
{
    for(int i = 0; i < 32; i++)
        imageBuffer[i] = ((imageBuffer[i]) & ~1) | ((size >> (31 - i)) & 1);
    return e_success;
}

/**************************************************************************************
 * Function Name : do_encoding
 * Description   : Main function that calls all other encoding steps in order
 **************************************************************************************/
Status do_encoding(EncodeInfo *encInfo)
{
    if(open_files(encInfo) != e_success) return e_failure;
    if(check_capacity(encInfo) != e_success) return e_failure;

    fseek(encInfo->fptr_src_image, 0, SEEK_SET); // Reset to start

    if(copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) != e_success) return e_failure;
    if(encode_magic_string(MAGIC_STRING, encInfo) != e_success) return e_failure;
    if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo) != e_success) return e_failure;
    if(encode_secret_file_extn(encInfo->extn_secret_file, encInfo) != e_success) return e_failure;
    if(encode_secret_file_size(encInfo->size_secret_file, encInfo) != e_success) return e_failure;
    if(encode_secret_file_data(encInfo) != e_success) return e_failure;
    if(copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) != e_success) return e_failure;

    printf("✅ Encoding completed successfully...\n");
    return e_success;
}
