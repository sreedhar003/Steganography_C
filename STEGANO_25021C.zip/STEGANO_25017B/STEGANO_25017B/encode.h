/**************************************************************************************
 File Name     : encode.h
 Description   : Contains function declarations and structure definitions used for
                  encoding secret data into BMP images in the Image Steganography project.
 Author        : S Sreedhar
 Date          : 23/10/2025
 Project       : LSB Image Steganography (Encoding Module)
 **************************************************************************************/

#ifndef ENCODE_H
#define ENCODE_H

#include <stdio.h>
#include "types.h"   // Contains user-defined types

/*
 * Structure Name : EncodeInfo
 * Description    : Stores information required for encoding secret data into
 *                  a source image. Includes source image, secret file, and
 *                  stego image details used during the encoding process.
 */
typedef struct _EncodeInfo
{
    /* Source Image info */
    char *src_image_fname;    // To store the source image file name
    FILE *fptr_src_image;     // To store the address of the source image file
    uint image_capacity;      // To store the size (capacity) of the image

    /* Secret File Info */
    char *secret_fname;       // To store the secret file name
    FILE *fptr_secret;        // To store the secret file address
    char extn_secret_file[5]; // To store the secret file extension
    char secret_data[100];    // To store the secret data
    long size_secret_file;    // To store the size of the secret data

    /* Stego Image Info */
    char *stego_image_fname;  // To store the stego (output) image file name
    FILE *fptr_stego_image;   // To store the address of the stego image
} EncodeInfo;

/*==============================================================================
 *                      Function Declarations
 *============================================================================*/

/* Read and validate Encode arguments from command line */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo);

/* Perform the encoding operation */
Status do_encoding(EncodeInfo *encInfo);

/* Open input and output files for processing */
Status open_files(EncodeInfo *encInfo);

/* Check whether the image has enough capacity to hide the secret data */
Status check_capacity(EncodeInfo *encInfo);

/* Get the size of the BMP image in bytes */
uint get_image_size_for_bmp(FILE *fptr_image);

/* Get the size of the file in bytes */
uint get_file_size(FILE *fptr);

/* Copy the BMP image header (first 54 bytes) from source to destination */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image);

/* Encode the magic string into the image */
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo);

/* Encode the size of the secret file extension */
Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo);

/* Encode the secret file extension into the image */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo);

/* Encode the size of the secret file data */
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo);

/* Encode the actual secret file data into the image */
Status encode_secret_file_data(EncodeInfo *encInfo);

/* Encode a single byte into the Least Significant Bits (LSBs) of image data */
Status encode_byte_to_lsb(char data, char *image_buffer);

/* Encode an integer size value into the LSBs of image data */
Status encode_size_to_lsb(int size, char *imageBuffer);

/* Copy remaining image bytes after encoding is complete */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest);

#endif /* ENCODE_H */
