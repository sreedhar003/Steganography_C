/**************************************************************************************
 File Name     : common.h
 Description   : Defines common macro used across encoding and decoding
                 modules in the LSB Image Steganography project.
 Author        : S Sreedhar
 Date          : 31/10/2025
 Project       : LSB Image Steganography (Common Definition)
 **************************************************************************************/

#ifndef COMMON_H
#define COMMON_H

/* Magic string to identify whether an image is stegged or not */
#define MAGIC_STRING "#*"

#endif /* COMMON_H */
