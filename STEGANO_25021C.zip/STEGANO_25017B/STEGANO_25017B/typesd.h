/**************************************************************************************
 File Name     : typesd.h
 Description   : Defines user-defined data types and status codes used in the 
                 decoding module of the LSB Image Steganography project.
 Author        : S Sreedhar
 Date          : 29/10/2025
 Project       : LSB Image Steganography (UDT definitions)
 **************************************************************************************/

#ifndef TYPESD_H
#define TYPESD_H

/* User-defined type for unsigned integer */
typedef unsigned int uint;

/* Status values used for decoding function return types */
typedef enum
{
    d_failure,  // Operation failed
    d_success   // Operation successful
} d_Status;

#endif /* TYPESD_H */
