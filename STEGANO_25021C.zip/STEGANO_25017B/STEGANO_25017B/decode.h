/**************************************************************************************
 File Name     : decode.h
 Description   : Contains function declarations and structure definitions used for
                  decoding hidden data from BMP images in the Image Steganography project.
 Author        : S Sreedhar
 Date          : 29/10/2025
 Project       : LSB Image Steganography (Decoding Part)
 **************************************************************************************/

#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "typesd.h"   // Contains user-defined types

/*
 Structure Name : EncodeInfod
 Description    : Stores information required for decoding hidden data from
                  stego (encoded) images. It includes source and secret file
                  details, output file information, and intermediate buffers.
 */
typedef struct _EncodeInfod
{
    /* Source Image info */
    char *src_image_fname;    // To store the source image name
    FILE *outputfptr;         // To store the address of the output image
    uint image_capacity;      // To store the size of the image

    /* Secret File Info */
    char *secret_fname;       // To store the secret file name
    FILE *fptr_secret;        // To store the secret file address
    char extn_secret_file[5]; // To store the secret file extension
    char secret_data[100];    // To store the secret data
    long size_secret_file;    // To store the size of the secret data

    /* Stego Image Info */
    char *stego_image_fname;  // To store the stego image file name
    FILE *fptr_stego_image;   // To store the address of the stego image
    char buffer[20];          // To store the temporary output file name
} EncodeInfod;

/*==============================================================================
 *                    Function Declarations                                    *
 *=============================================================================*/

/* Read and validate Decode arguments from command line */
d_Status read_and_validate_decode_args(int argc, char *argv[], EncodeInfod *encInfod);

/* Perform the decoding process */
d_Status do_decoding(EncodeInfod *encInfo);

/* Decode and verify the magic string */
d_Status decode_magic_string(char *magic_string, EncodeInfod *encInfo);

/* Decode the size of the secret file extension */
d_Status decode_secret_file_extn_size(long int *size, EncodeInfod *encInfo);

/* Decode the secret file extension */
d_Status decode_extn(int *size, EncodeInfod *encInfod);

/* Decode the secret file size */
d_Status decode_secret_file_size(long *file_size, EncodeInfod *decodeInfo);

/* Decode the actual secret file data */
d_Status decode_secret_file_data(EncodeInfod *decodInfo);

/* Decode a single byte from the LSBs of image data */
d_Status decode_byte_from_lsb(char *data, char *image_buffer);

/* Decode an integer size value from the LSBs of image data */
d_Status decode_size_from_lsb(long int *size, char *imageBuffer);

#endif /* DECODE_H */
