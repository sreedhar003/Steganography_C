/**************************************************************************************
 * File Name     : types.h
 * Description   : Contains user-defined data types and enumerations used across
 *                 encoding part of the LSB Image Steganography project.
 * Author        : S Sreedhar
 * Date          : 23/10/2025
 * Project       : LSB Image Steganography (UDT definitions)
 **************************************************************************************/

#ifndef TYPES_H
#define TYPES_H

/* User-defined type for unsigned integer */
typedef unsigned int uint;

/* Status values used for function return types */
typedef enum
{
    e_failure,  // Operation failed
    e_success   // Operation successful
} Status;

/* Operation modes for the project */
typedef enum
{
    e_encode,       // Encoding mode
    e_decode,       // Decoding mode
    e_unsupported   // Unsupported operation
} OperationType;

#endif /* TYPES_H */
