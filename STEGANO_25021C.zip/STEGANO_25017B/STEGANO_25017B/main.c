/**************************************************************************************
 * File Name     : main.c
 * Description   : Entry point for the LSB Image Steganography project. 
 *                 This file controls both encoding and decoding operations 
 *                 for hiding and extracting secret information within BMP images.
 *
 * Project Title : LSB Image Steganography (Main Part)
 * Author        : S Sreedhar
 * Date          : 23/10/2025
 *
 *--------------------------------------------------------------------------------------
 * Project Overview :
 *   LSB Image Steganography is the process of encoding the secret data (like .text/.c/.h etc..)
 *   within an image file.
 *   This project focuses on hiding data inside BMP files by changing 
 *   the Least Significant Bits (LSB) of pixel data to encode information securely.
 *
 * Features :
 *   1. Encoding - Hide a secret text/file within a BMP image.
 *   2. Decoding - Extract the hidden message from the encoded image.
 *   3. Magic String Verification - Ensures that the image contains valid magic string or not.
 *   4. Validation of Input Arguments - Checks the correctness of filenames and formats passed in the command line.
 *
 * Usage :
 *   For Encoding:
 *       ./a.out -e <source.bmp> <secret.txt> <output_stego.bmp>(optional)
 *
 *   For Decoding:
 *       ./a.out -d <stego.bmp> <output_decoded.txt>(optional)
 *----------------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include "typesd.h"

/*==============================================================================
 *                      Function Declaration
 *============================================================================*/

/* Function to determine the operation type: encode or decode */
OperationType check_operation_type(char *symbol);

/*==============================================================================
 *                                main()
 *------------------------------------------------------------------------------
 * Description : Main function that handles the encoding and decoding part.
 * Arguments   : argc - Number of command-line arguments
 *               argv - Array of argument strings
 *============================================================================*/

int main(int argc, char *argv[])
{
    /* Display project title in stylized text */
    system("echo -e \"\033[1;36m$(figlet -f slant STEGNOGRAPHY)\033[0m\"");

    EncodeInfo enc_info;   // Structure for encoding
    EncodeInfod decode;    // Structure for decoding

    /*------------------------------------------------------
     * Encoding Operation
     *----------------------------------------------------*/
    if (check_operation_type(argv[1]) == e_encode)
    {
        if (argc >= 4)
        {
        system("echo -e \"\033[1;33m$(figlet -f digital 'Encoding Mode...')\033[0m\"");


        // Validate input arguments
        if (read_and_validate_encode_args(argv, &enc_info) == e_success)
          {
            // Perform encoding if validation succeeds
            if (do_encoding(&enc_info) != e_success)
            {
                printf("Encoding stopped due to an error.\n");
                return 0;
            }
          }    
        }
        else
        {
        printf("Invalid encoding arguments. Terminating...\n");
        return 0;
        }
    }
    

    /*------------------------------------------------------
     * Decoding Operation
     *----------------------------------------------------*/
   if (check_operation_type(argv[1]) == e_decode)
    {
    if (argc == 3 || argc == 4)
    {
        system("echo -e \"\033[1;32m$(figlet -f digital 'Decoding Mode...')\033[0m\"");


        // Validate input arguments
        if (read_and_validate_decode_args(argc, argv, &decode) == d_success)
        {
            // Perform decoding if validation succeeds
            if (do_decoding(&decode) != d_success)
            {
                printf("Decoding stopped due to an error.\n");
                return 0;
            }
        }
        else
        {
            printf("Invalid decoding arguments. Terminating...\n");
            return 0;
        }
    }
    else
    {
        printf("Insufficient decoding arguments. Terminating...\n");
        return 0;
    }
    }

}

/*==============================================================================
 *                      Function Definition
 *============================================================================*/

/**************************************************************************************
 * Function Name : check_operation_type
 * Description   : Identifies the operation type based on user input.
 * Arguments     : symbol - The command-line argument indicating the operation (-e or -d)
 * Return Type   : OperationType
 *                 e_encode       - For encoding operation
 *                 e_decode       - For decoding operation
 *                 e_unsupported  - For invalid operation
 **************************************************************************************/
OperationType check_operation_type(char *symbol)
{
    if (strcmp(symbol, "-e") == 0)
        return e_encode;

    if (strcmp(symbol, "-d") == 0)
        return e_decode;

    printf("Invalid Operation! Use -e for encoding or -d for decoding.\n");
    return e_unsupported;
}
