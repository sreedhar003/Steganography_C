/**************************************************************************************
 File Name     : decode.c
 Description   : Contains all function definitions for decoding hidden data from BMP
 Author        : S Sreedhar
 Date          : 29/10/2025
 Project       : LSB Image Steganography (Decoding Part)
 **************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "typesd.h"
#include "common.h"
#include "decode.h"

/**************************************************************************************
 Function Name : read_and_validate_decode_args
 Description   : Validates command-line arguments and opens the stego BMP file
 Input         : argc, argv[], and EncodeInfod structure pointer
 Output        : d_success or d_failure
 **************************************************************************************/
d_Status read_and_validate_decode_args(int argc, char *argv[], EncodeInfod *encInfod)
{
    // Must have at least 3 arguments: ./a.out -d <stego.bmp>
    if (argc < 3)
        return d_failure;

    // Validate stego image file extension
    if (strstr(argv[2], ".bmp") == NULL)
        return d_failure;

    encInfod->stego_image_fname = argv[2]; // Store file name

    // Open stego image for reading in binary mode
    encInfod->fptr_stego_image = fopen(encInfod->stego_image_fname, "rb");
    if (encInfod->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfod->stego_image_fname);
        return d_failure;
    }

    // Optional output filename argument
    if (argc == 4)
    {
        strcpy(encInfod->buffer, strtok(argv[3], ".")); 
        if (!(encInfod->buffer))
            return d_failure;
    }
    else
    {
        // Default output name
        strcpy(encInfod->buffer, "output");
    }

    return d_success;
}

/**************************************************************************************
 Function Name : decode_magic_string
 Description   : Reads and verifies the encoded magic string from the stego image
 **************************************************************************************/
d_Status decode_magic_string(char *magic_string, EncodeInfod *encInfo)
{
    char image[8];
    int size = strlen(MAGIC_STRING); // Length of reference magic string

    for (int i = 0; i < size; i++)
    {
        // Read 8 bytes from stego image
        if (fread(image, 1, 8, encInfo->fptr_stego_image) != 8)
        {
            fprintf(stderr, "ERROR: Unable to read 8 bytes from image\n");
            return d_failure;
        }

        // Decode 1 byte from 8 LSBs
        if (decode_byte_from_lsb(&magic_string[i], image) != d_success)
            return d_failure;
    }

    magic_string[size] = '\0'; // Null-terminate decoded string

    // Compare decoded magic string with expected value
    if (strcmp(magic_string, MAGIC_STRING) == 0)
    {
        printf("Magic String verified successfully\n");
        return d_success;
    }
    else
    {
        printf("Magic String Verification failed\n");
        printf("Decoded Value: %s\n", magic_string);
        return d_failure;
    }
}

/**************************************************************************************
 Function Name : decode_secret_file_extn_size
 Description   : Decodes and retrieves the size of the secret file extension
 **************************************************************************************/
d_Status decode_secret_file_extn_size(long int *size, EncodeInfod *encInfo)
{
    char image[32];
    fread(image, 1, 32, encInfo->fptr_stego_image); // Read 32 bytes from stego image
    decode_size_from_lsb(size, image);               // Extract 32-bit integer from LSBs
    return d_success;
}

/**************************************************************************************
 Function Name : decode_extn
 Description   : Decodes the secret file extension and creates output file
 **************************************************************************************/
d_Status decode_extn(int *size, EncodeInfod *encInfod)
{
    char extension[*size + 1]; // Temporary buffer for extension
    char image[8];

    // Decode each byte of extension
    for (int i = 0; i < *size; i++)
    {
        fread(image, 1, 8, encInfod->fptr_stego_image);
        decode_byte_from_lsb(&extension[i], image);
    }
    extension[*size] = '\0'; // Null-terminate

    // Copy decoded extension into structure
    strcpy(encInfod->extn_secret_file, extension);

    // Append extension to output file name
    if (encInfod->buffer != NULL)
        strcat(encInfod->buffer, extension);

    // Create output file in binary write mode
    encInfod->outputfptr = fopen(encInfod->buffer, "wb");
    if (encInfod->outputfptr == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfod->buffer);
        return d_failure;
    }

    printf("Decoded file extension: %s\n", extension);
    printf("Output file created: %s\n", encInfod->buffer);
    return d_success;
}

/**************************************************************************************
 Function Name : decode_secret_file_size
 Description   : Decodes the total size of the secret file in bytes
 **************************************************************************************/
d_Status decode_secret_file_size(long *file_size, EncodeInfod *decodeInfo)
{
    *file_size = 0;
    char image[32];

    fread(image, 1, 32, decodeInfo->fptr_stego_image); // Read next 32 bytes
    decode_size_from_lsb(file_size, image);             // Decode file size

    printf("Decoded secret file size: %ld bytes\n", *file_size);
    return d_success;
}

/**************************************************************************************
 Function Name : decode_secret_file_data
 Description   : Decodes actual hidden data from the image and writes to output file
 **************************************************************************************/
d_Status decode_secret_file_data(EncodeInfod *decodInfo)
{
    long size = decodInfo->size_secret_file;

    // Allocate buffer to store decoded data
    char *secret_data = malloc(size);
    if (!secret_data)
    {
        fprintf(stderr, "ERROR: Memory allocation failed\n");
        return d_failure;
    }

    char image_buffer[8];

    // Decode each byte of secret data
    for (long i = 0; i < size; i++)
    {
        if (fread(image_buffer, 1, 8, decodInfo->fptr_stego_image) != 8)
        {
            fprintf(stderr, "ERROR: Unable to read 8 bytes from image\n");
            free(secret_data);
            return d_failure;
        }

        if (decode_byte_from_lsb(&secret_data[i], image_buffer) != d_success)
        {
            free(secret_data);
            return d_failure;
        }
    }

    // Write decoded data to output file
    if (fwrite(secret_data, 1, size, decodInfo->outputfptr) != size)
    {
        fprintf(stderr, "ERROR: Unable to write all decoded data to output file\n");
        free(secret_data);
        return d_failure;
    }

    fclose(decodInfo->outputfptr); // Close output file
    free(secret_data);             // Free memory

    printf("✅ Secret file data successfully decoded and written!\n");
    return d_success;
}

/**************************************************************************************
 Function Name : decode_byte_from_lsb
 Description   : Extracts 8 bits from LSBs of 8 bytes to form a single byte of data
 **************************************************************************************/
d_Status decode_byte_from_lsb(char *data, char *image_buffer)
{
    *data = 0;
    for (int i = 0; i < 8; i++)
        *data = (*data << 1) | (image_buffer[i] & 1); // Shift and OR LSB
    return d_success;
}

/**************************************************************************************
 Function Name : decode_size_from_lsb
 Description   : Extracts a 32-bit integer from LSBs of 32 bytes
 **************************************************************************************/
d_Status decode_size_from_lsb(long int *size, char *imageBuffer)
{
    *size = 0;
    for (int i = 0; i < 32; i++)
        *size = (*size << 1) | (imageBuffer[i] & 1);
    return d_success;
}

/**************************************************************************************
 Function Name : do_decoding
 Description   : Main function that performs the entire decoding sequence
 **************************************************************************************/
d_Status do_decoding(EncodeInfod *encInfo)
{
    // Skip BMP header (first 54 bytes)
    fseek(encInfo->fptr_stego_image, 54, SEEK_SET);

    char magic_string[strlen(MAGIC_STRING) + 1];

    // Verify magic string
    if (decode_magic_string(magic_string, encInfo) != d_success)
    {
        printf("Magic string verification failed! Not a valid stego image.\n");
        return d_failure;
    }

    long int extn_size;

    // Decode extension size, extension, file size, and secret data sequentially
    if (decode_secret_file_extn_size(&extn_size, encInfo) != d_success)
        return d_failure;

    if (decode_extn((int *)&extn_size, encInfo) != d_success)
        return d_failure;

    if (decode_secret_file_size(&encInfo->size_secret_file, encInfo) != d_success)
        return d_failure;

    if (decode_secret_file_data(encInfo) != d_success)
        return d_failure;

    printf("✅ Decoding completed successfully...\n");
    return d_success;
}
